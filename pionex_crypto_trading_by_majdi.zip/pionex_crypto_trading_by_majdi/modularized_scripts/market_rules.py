def fetch_min_trade_size(client, symbol):
    """Fetch the minimum trade size and related constraints for a given trading pair."""
    try:
        response = client.get_symbols()
        symbols_info = response.get("symbols", [])
        for info in symbols_info:
            if info.get("symbol") == symbol:
                min_trade_size = float(info.get("minTradeSize", 0.0))
                amount_precision = int(info.get("amountPrecision", 8))
                logging.info(f"Minimum trade size for {symbol}: {min_trade_size}, Amount Precision: {amount_precision}")
                return min_trade_size, amount_precision
        logging.error(f"Minimum trade size not found for symbol {symbol}.")
    except Exception as e:
        logging.error(f"Error fetching minimum trade size for {symbol}: {e}")
    return None, None

def get_signature(api_secret, method, url, timestamp, query, body=""):
    signature_string = f"{method}{url}{query}{timestamp}{body}"
    return hmac.new(api_secret.encode(), signature_string.encode(), hashlib.sha256).hexdigest()

def place_sell_order(symbol, size):
    """Place a market sell order."""
    try:
        logging.info(f"Attempting to place sell order for {symbol} with trade size: {size}")
        if size <= 0:
            logging.error("Invalid trade size.")
            return False

        api_key, api_secret = get_next_credentials()
        orders_client = Orders(api_key, api_secret)

        # Use PionexClient to fetch minimum trade size, amount precision, and min amount
        client = PionexClient(api_key, api_secret)
        min_trade_size, amount_precision = fetch_min_trade_size(client, symbol)
        if not min_trade_size or size < min_trade_size:
            logging.error(f"Trade size {size} is below the minimum trade size {min_trade_size} for {symbol}.")
            return False

        # Adjust the precision based on the trading pair's constraints
        size = round_to_precision(size, 2)
        size_str = f"{size:.2f}"  # Round to two decimal places for all

        logging.info(f"Formatted trade size: {size_str}")

        # Ensure trade size meets minimum trade amount
        if float(size) * fetch_price(client, symbol) < min_trade_size:
            logging.error(f"Trade size {size} is below the minimum trade value {min_trade_size} for {symbol}.")
            return False

        # Prepare headers and payload
        timestamp = int(time.time() * 1000)
        method = "POST"
        url = "/api/v1/trade/order"
        query = f"timestamp={timestamp}"

        signature = get_signature(api_secret, method, url, timestamp, query)
        headers = {
            "PIONEX-KEY": api_key,
            "PIONEX-SIGNATURE": signature,
            "Content-Type": "application/json",
            "timestamp": str(timestamp),
        }
        payload = {
            "symbol": symbol,
            "side": "SELL",
            "type": "MARKET",
            "size": size_str,
        }
        logging.info(f"API Request Headers: {json.dumps(headers)}")
        logging.info(f"API Request Payload: {json.dumps(payload)}")

        response = orders_client.new_order(**payload)

        if response:
            logging.info(f"Sell order response for {symbol}: {response}")
            if response.get("result", False):
                logging.info(f"Sell order placed successfully for {symbol}: {response}")
                return True
            else:
                logging.error(f"Failed to place sell order for {symbol}. Response: {response}")
                logging.error(f"API Error Details: {response}")
                return False
        else:
            logging.error(f"No response received when placing sell order for {symbol}.")
            return False
    except Exception as e:
        logging.error(f"Error placing sell order for {symbol}: {e}")
        return False

def fetch_supported_symbols(client):
    """Fetch and log supported symbols from the Pionex API."""
    try:
        response = client.get_symbols()
        symbols = [symbol['symbol'] for symbol in response.get('symbols', [])]
        logging.info(f"Supported symbols: {symbols}")
        return symbols
    except Exception as e:
        logging.error(f"Error fetching supported symbols: {e}")
        return []

def execute_selling():
    """Main selling logic to sell 30 USDT worth of each asset."""
    try:
        api_key, api_secret = get_next_credentials()
        client = PionexClient(api_key, api_secret)

        supported_symbols = fetch_supported_symbols(client)

        for pair in LIQUID_PAIRS:
            if pair not in supported_symbols:
                logging.warning(f"Symbol {pair} is not supported. Skipping...")
                continue

            # Fetch price
            price = fetch_price(client, pair)
            logging.info(f"Fetched price for {pair}: {price}")
            if not price:
                logging.warning(f"Unable to fetch price for {pair}. Skipping...")
                continue

            # Calculate trade size
            min_trade_size, amount_precision = fetch_min_trade_size(client, pair)
            trade_size = calculate_trade_size(price, target_value=BASE_TARGET_TRADE_VALUE, min_trade_size=min_trade_size, buffer_percentage=BUFFER_PERCENTAGE, amount_precision=amount_precision)
            logging.info(f"Calculated trade size for {pair}: {trade_size}")
            if trade_size == 0:
                logging.warning(f"Trade size for {pair} is invalid. Skipping...")
                continue

            # Place the sell order
            if place_sell_order(pair, trade_size):
                logging.info(f"Successfully sold 30.0 USDT worth of {pair}.")
                
    except Exception as e:
        logging.error(f"Error in execute_selling: {e}")

if __name__ == "__main__":
    execute_selling()

