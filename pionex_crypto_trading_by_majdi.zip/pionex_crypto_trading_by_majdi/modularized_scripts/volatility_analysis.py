def check_price_volatility(prices, volatility_threshold, market_monitoring_log_path):
    # Check for price volatility
    if len(prices) >= 2:
        price_change = abs((prices[-1] - prices[0]) / prices[0])
        if price_change >= volatility_threshold:
            log_event("Volatility Detected", {
                "price_change_percentage": price_change,
                "prices": prices
            }, "Market Monitoring", market_monitoring_log_path)
            print(f"Volatility detected: {price_change * 100:.2f}%")
            return True
    return False

# Check bid-ask spread
def check_bid_ask_spread(bid_price, ask_price, spread_threshold, market_monitoring_log_path):
    if bid_price and ask_price:
        spread = (ask_price - bid_price) / bid_price
        if spread >= spread_threshold:
            log_event("High Spread Detected", {
                "bid_price": bid_price,
                "ask_price": ask_price,
                "spread_percentage": spread
            }, "Market Monitoring", market_monitoring_log_path)
            print(f"High bid-ask spread detected: {spread * 100:.2f}%")
            return True
    return False

def initialize_connections():
    """Initialize public and private WebSocket connections."""
    # URLs for public and private WebSocket endpoints
    public_ws_url = os.getenv("PUBLIC_WEBSOCKET_URL")
    private_ws_url = os.getenv("PRIVATE_WEBSOCKET_URL")

    # Initialize public WebSocket connection
    public_ws = PublicStreamHandler(url=public_ws_url)
    private_ws = PrivateStreamHandler(url=private_ws_url)

    return public_ws, private_ws

async def main():
    # Configuration for market monitoring
    config = {
        "volatility_threshold": 0.05,
        "spread_threshold": 0.02,
        "cooldown_minutes": 5
    }

    # Example data for monitoring
    prices = [50000, 52500]
    bid_price = 49900
    ask_price = 51000

    try:
        # Initialize WebSocket connections
        public_ws, private_ws = initialize_connections()

        # Connect to both WebSockets
        await public_ws.connect()
        await private_ws.connect()

        # Authenticate private WebSocket
        await private_ws.authenticate()

        # Subscribe to topics (example)
        await public_ws.subscribe("TRADE", "BTC_USDT")
        await private_ws.subscribe("BALANCE")

        # Monitor market conditions in a loop
        while True:
            if monitor_market_conditions(prices, bid_price, ask_price, config):
                print(f"Pausing trading for {config['cooldown_minutes']} minutes...")
                await asyncio.sleep(config["cooldown_minutes"] * 60)

    except KeyboardInterrupt:
        print("\nBot interrupted manually. Exiting gracefully...")

    except Exception as e:
        log_error('WebSocket', 'Error', f"An error occurred in the main function: {e}")
        raise

    finally:
        # Ensure WebSocket connections are closed
        try:
            await public_ws.disconnect()
            await private_ws.disconnect()
        except Exception as cleanup_error:
            log_error("WebSocket", "CleanupError", f"Error during cleanup: {cleanup_error}")
        print("Connections closed. Goodbye.")
        # Ensure WebSocket connections are closed
        try:
            await public_ws.disconnect()
            await private_ws.disconnect()
        except Exception as cleanup_error:
            log_error("WebSocket", "CleanupError", f"Error during cleanup: {cleanup_error}")
        print("Connections closed. Goodbye.")

if __name__ == "__main__":
    try:
        asyncio.get_event_loop().run_until_complete(main())
    except KeyboardInterrupt:
        print("\nBot manually stopped. Goodbye!")

def check_bid_ask_spread(bid_price, ask_price, spread_threshold, market_monitoring_log_path):
    if bid_price and ask_price:
        spread = (ask_price - bid_price) / bid_price
        if spread >= spread_threshold:
            log_event("High Spread Detected", {
                "bid_price": bid_price,
                "ask_price": ask_price,
                "spread_percentage": spread
            }, "Market Monitoring", market_monitoring_log_path)
            print(f"High bid-ask spread detected: {spread * 100:.2f}%")
            return True
    return False

def initialize_connections():
    """Initialize public and private WebSocket connections."""
    # URLs for public and private WebSocket endpoints
    public_ws_url = os.getenv("PUBLIC_WEBSOCKET_URL")
    private_ws_url = os.getenv("PRIVATE_WEBSOCKET_URL")

    # Initialize public WebSocket connection
    public_ws = PublicStreamHandler(url=public_ws_url)
    private_ws = PrivateStreamHandler(url=private_ws_url)

    return public_ws, private_ws

async def main():
    # Configuration for market monitoring
    config = {
        "volatility_threshold": 0.05,
        "spread_threshold": 0.02,
        "cooldown_minutes": 5
    }

    # Example data for monitoring
    prices = [50000, 52500]
    bid_price = 49900
    ask_price = 51000

    try:
        # Initialize WebSocket connections
        public_ws, private_ws = initialize_connections()

        # Connect to both WebSockets
        await public_ws.connect()
        await private_ws.connect()

        # Authenticate private WebSocket
        await private_ws.authenticate()

        # Subscribe to topics (example)
        await public_ws.subscribe("TRADE", "BTC_USDT")
        await private_ws.subscribe("BALANCE")

        # Monitor market conditions in a loop
        while True:
            if monitor_market_conditions(prices, bid_price, ask_price, config):
                print(f"Pausing trading for {config['cooldown_minutes']} minutes...")
                await asyncio.sleep(config["cooldown_minutes"] * 60)

    except KeyboardInterrupt:
        print("\nBot interrupted manually. Exiting gracefully...")

    except Exception as e:
        log_error('WebSocket', 'Error', f"An error occurred in the main function: {e}")
        raise

    finally:
        # Ensure WebSocket connections are closed
        try:
            await public_ws.disconnect()
            await private_ws.disconnect()
        except Exception as cleanup_error:
            log_error("WebSocket", "CleanupError", f"Error during cleanup: {cleanup_error}")
        print("Connections closed. Goodbye.")
        # Ensure WebSocket connections are closed
        try:
            await public_ws.disconnect()
            await private_ws.disconnect()
        except Exception as cleanup_error:
            log_error("WebSocket", "CleanupError", f"Error during cleanup: {cleanup_error}")
        print("Connections closed. Goodbye.")

if __name__ == "__main__":
    try:
        asyncio.get_event_loop().run_until_complete(main())
    except KeyboardInterrupt:
        print("\nBot manually stopped. Goodbye!")