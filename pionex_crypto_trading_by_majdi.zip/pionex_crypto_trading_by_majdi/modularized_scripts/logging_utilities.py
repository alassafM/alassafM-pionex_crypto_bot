import json

import logging
import os
from pathlib import Path


def log_json(file_path, data):
    
    print(f"DEBUG: Inside log_json - file_path={file_path}, absolute_path={os.path.abspath(file_path)}, data={data}")
    
    
    print(f"DEBUG: Writing to file_path={file_path} with data={data}")
    with open(os.path.abspath(file_path), "a") as file:
        json.dump(data, file)
        file.write("\n")  # Add a newline for readability


def log_event(log_file, event_type, event_details):
    print(f"DEBUG: log_file={log_file}, event_type={event_type}, event_details={event_details}")
    
    print(f"DEBUG: Log file={log_file}, Event Type={event_type}, Event Details={event_details}")
    log_data = {
        "event_type": event_type,
        "event_details": event_details
    }
    log_json(log_file, log_data)
