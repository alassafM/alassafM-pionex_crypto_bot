
import os
from modularized_scripts.logging_utilities import log_event

# Define a test log file path and event details
test_log_file = os.path.join("/mnt/data/pionex_crypto_trading/pionex_crypto_trading/logs", "test_logging.json")
test_event_type = "Test Event"
test_event_details = {"key": "value", "status": "success"}

# Simulate logging
try:
    print("Starting log_event test...")
    log_event(test_log_file, test_event_type, test_event_details)
    print("log_event executed successfully.")
except Exception as e:
    print(f"log_event test failed: {e}")
