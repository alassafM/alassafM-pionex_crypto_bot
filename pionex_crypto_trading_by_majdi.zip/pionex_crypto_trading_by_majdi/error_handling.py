
import time

def handle_rate_limit(headers):
    """Handles API rate limits based on headers."""
    reset_time = int(headers.get('X-RateLimit-Reset', time.time()))
    wait_time = max(0, reset_time - int(time.time()))
    if wait_time > 0:
        time.sleep(wait_time)

def handle_websocket_error(attempt, max_retries=5):
    """Handles WebSocket errors with retry logic."""
    if attempt >= max_retries:
        raise ConnectionError("Max retries reached for WebSocket connection.")
    time.sleep(attempt ** 2)  # Exponential backoff
