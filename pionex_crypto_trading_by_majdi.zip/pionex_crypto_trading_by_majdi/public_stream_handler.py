
import asyncio
import aiohttp
import json
import time

class PublicStreamHandler:
    def __init__(self, url="wss://public.websocket.pionex.com"):
        self.url = url
        self.connection = None

    async def connect(self):
        """Connect to the public WebSocket stream."""
        try:
            session = aiohttp.ClientSession()
            self.connection = await session.ws_connect(self.url)
            print(f"Connected to {self.url}")
        except Exception as e:
            print(f"Failed to connect to public stream: {e}")

    async def subscribe(self, topic, symbol, limit=5):
        """Subscribe to a public stream topic."""
        try:
            if not self.connection:
                print("No active WebSocket connection. Call connect() first.")
                return
            payload = {
                "op": "SUBSCRIBE",
                "topic": topic,
                "symbol": symbol,
                "limit": limit
            }
            await self.connection.send_json(payload)
            print(f"Subscribed to topic {topic} for symbol {symbol}")
        except Exception as e:
            print(f"Failed to subscribe to {topic}: {e}")

    async def receive_messages(self):
        """Listen for messages from the WebSocket."""
        try:
            if not self.connection:
                print("No active WebSocket connection. Call connect() first.")
                return
            while True:
                msg = await self.connection.receive()
                if msg.type == aiohttp.WSMsgType.TEXT:
                    print(f"Message received: {msg.data}")
                elif msg.type == aiohttp.WSMsgType.ERROR:
                    print(f"Error received: {msg.data}")
                elif msg.type == aiohttp.WSMsgType.CLOSED:
                    print("WebSocket connection closed by server.")
                    break
        except Exception as e:
            print(f"Error while receiving messages: {e}")

    async def disconnect(self):
        """Disconnect the WebSocket connection."""
        try:
            if self.connection:
                await self.connection.close()
                print("Disconnected from WebSocket.")
        except Exception as e:
            print(f"Failed to disconnect: {e}")
