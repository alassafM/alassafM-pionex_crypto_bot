
from modularized_scripts.logging_utilities import log_event

# Test parameters for log_event
test_log_file = "logs/market_monitoring.json"
test_event_type = "Volatility Detected"
test_event_details = {"key": "value", "threshold": "high"}

# Simulate calling log_event
try:
    print("Starting log_event test...")
    log_event(test_log_file, test_event_type, test_event_details)
    print("log_event executed successfully.")
except Exception as e:
    print(f"log_event test failed: {e}")
