import aiohttp
import asyncio
import json
import hmac
from hashlib import sha256
import time
from dotenv import load_dotenv
import os

# Load API credentials from .env file
load_dotenv()
API_KEY = os.getenv("API_KEY")
API_SECRET = os.getenv("SECRET_KEY")


class PionexWebSocketClient:
    def __init__(self, topics=None):
        self.api_key = API_KEY
        self.api_secret = API_SECRET
        self.endpoint = "wss://ws.pionex.com/ws"  # Hardcoded for private streams
        self.ws = None
        self.topics = topics or []

    def _generate_signature(self, timestamp):
        """Generate HMAC signature for authentication."""
        message = f"key={self.api_key}&timestamp={timestamp}websocket_auth"
        return hmac.new(self.api_secret.encode(), message.encode(), sha256).hexdigest()

    async def connect(self):
        """Establish the WebSocket connection."""
        try:
            timestamp = int(time.time() * 1000)
            signature = self._generate_signature(timestamp)
            url = f"{self.endpoint}?key={self.api_key}&timestamp={timestamp}&signature={signature}"

            async with aiohttp.ClientSession() as session:
                self.ws = await session.ws_connect(url, headers={
                    "User-Agent": "PionexWebSocketClient",
                    "Content-Type": "application/json",
                })
                print(f"Connected to {url}")
        except Exception as e:
            print(f"Connection failed: {e}")

    async def subscribe(self):
        """Subscribe to topics."""
        if not self.ws:
            print("WebSocket is not connected. Cannot subscribe.")
            return

        for topic in self.topics:
            payload = {"op": "SUBSCRIBE", "topic": topic}
            if topic == "ORDER":
                payload["symbol"] = "BTC_USDT"  # Example symbol; replace as needed
            await self.ws.send_json(payload)
            print(f"Subscribed to: {topic}")

    async def receive_json(self):
        """Receive and process a JSON-formatted message."""
        try:
            async for msg in self.ws:
                if msg.type == aiohttp.WSMsgType.TEXT:
                    message = json.loads(msg.data)
                    if message.get("op") == "PING":
                        await self.ws.send_json({"op": "PONG", "timestamp": int(time.time() * 1000)})
                        print("PONG sent to server.")
                    print(f"Received message: {message}")
                elif msg.type == aiohttp.WSMsgType.ERROR:
                    print(f"WebSocket error: {msg.data}")
        except Exception as e:
            print(f"Failed to receive message: {e}")

    async def run(self):
        """Run the WebSocket client."""
        await self.connect()
        if self.ws:
            await self.subscribe()
            await self.receive_json()


# Example usage
async def main():
    topics = ["BALANCE", "ORDER"]  # Replace with desired topics
    client = PionexWebSocketClient(topics=topics)
    await client.run()

# Run the client
asyncio.run(main())
