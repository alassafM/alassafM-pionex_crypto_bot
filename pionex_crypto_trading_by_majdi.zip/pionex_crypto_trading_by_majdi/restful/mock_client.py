import random
import logging
from datetime import datetime, timedelta

class MockPionexClient:
    def __init__(self):
        # Initialize mock data
        self.balances = {
            "BTC": {"free": 0.5, "frozen": 0.0},
            "ETH": {"free": 1.0, "frozen": 0.0},
            "USDT": {"free": 1000.0, "frozen": 0.0}
        }
        self.candlestick_data = self.generate_mock_candlestick_data()
        self.orders = []  # Simulate placed orders
        self.log_file = "mock_client.log"

        # Configure logging
        logging.basicConfig(
            filename=self.log_file,
            level=logging.DEBUG,
            format="%(asctime)s - %(levelname)s - %(message)s"
        )

    def generate_mock_candlestick_data(self):
        """Generate mock candlestick data for multiple intervals."""
        intervals = ["1M", "5M", "15M"]
        data = {}
        for interval in intervals:
            data[interval] = [
                {
                    "time": (datetime.now() - timedelta(minutes=i)).timestamp() * 1000,
                    "open": round(1800 + random.uniform(-10, 10), 2),
                    "close": round(1800 + random.uniform(-10, 10), 2),
                    "high": round(1800 + random.uniform(0, 15), 2),
                    "low": round(1800 - random.uniform(0, 15), 2),
                    "volume": round(random.uniform(0.1, 1.0), 3)
                }
                for i in range(50)
            ]
        return data

    def get_account(self):
        """Simulate fetching account balances."""
        logging.info("Fetching mock balances.")
        return {
            "data": {"balances": [
                {"coin": coin, "free": str(balance["free"]), "frozen": str(balance["frozen"])}
                for coin, balance in self.balances.items()
            ]},
            "result": True,
            "timestamp": int(datetime.now().timestamp() * 1000)
        }

    def get_klines(self, symbol, interval="1M", limit=50):
        """Simulate fetching candlestick data."""
        logging.info(f"Fetching mock candlestick data for {symbol}, interval={interval}, limit={limit}.")
        if interval not in self.candlestick_data:
            logging.error(f"Invalid interval requested: {interval}.")
            return {"result": False, "data": []}

        return {
            "result": True,
            "data": self.candlestick_data[interval][:limit],
            "timestamp": int(datetime.now().timestamp() * 1000)
        }

    def create_order(self, symbol, side, order_type, quantity):
        """Simulate placing an order."""
        logging.info(f"Placing mock {side} order for {symbol}, quantity={quantity}.")
        if float(quantity) <= 0:
            logging.error("Order failed: quantity must be greater than 0.")
            return {
                "result": False,
                "message": "TRADE_PARAMETER_ERROR: Invalid quantity."
            }

        # Simulate a successful order
        order_id = random.randint(1000000000, 9999999999)
        order = {
            "orderId": order_id,
            "symbol": symbol,
            "side": side,
            "type": order_type,
            "quantity": quantity,
            "status": "FILLED",
            "timestamp": int(datetime.now().timestamp() * 1000)
        }
        self.orders.append(order)

        return {
            "result": True,
            "data": {"orderId": order_id},
            "timestamp": order["timestamp"]
        }

    def get_trades(self, symbol, limit=1):
        """Simulate fetching recent trades."""
        logging.info(f"Fetching mock trades for {symbol}, limit={limit}.")
        return {
            "data": [
                {
                    "symbol": symbol,
                    "tradeId": random.randint(1000000, 9999999),
                    "price": str(round(1800 + random.uniform(-10, 10), 2)),
                    "size": str(round(random.uniform(0.01, 0.1), 3)),
                    "side": "BUY" if random.choice([True, False]) else "SELL",
                    "timestamp": int(datetime.now().timestamp() * 1000)
                }
                for _ in range(limit)
            ],
            "result": True,
            "timestamp": int(datetime.now().timestamp() * 1000)
        }
