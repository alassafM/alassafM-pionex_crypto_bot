
import hmac
import hashlib
import time
import requests
import json

class Orders:
    API_BASE_URL = "https://api.pionex.com"

    def __init__(self, api_key: str, api_secret: str):
        self.api_key = api_key
        self.api_secret = api_secret

    def _generate_signature(self, params: dict) -> str:
        """Generate HMAC SHA256 signature for authentication."""
        query_string = "&".join(f"{key}={value}" for key, value in sorted(params.items()))
        return hmac.new(self.api_secret.encode(), query_string.encode(), hashlib.sha256).hexdigest()

    def _send_request(self, method: str, endpoint: str, params: dict = None, data: dict = None) -> dict:
        """Send a request to the Pionex API."""
        url = f"{self.API_BASE_URL}{endpoint}"
        headers = {"X-MBX-APIKEY": self.api_key}

        if params:
            params["signature"] = self._generate_signature(params)

        response = requests.request(method, url, headers=headers, params=params, json=data)

        if response.status_code == 200:
            return response.json()
        else:
            return {"error": response.text}

    def place_order(self, symbol: str, side: str, quantity: float, price: float) -> dict:
        """Place a new order."""
        params = {
            "symbol": symbol,
            "side": side,
            "type": "LIMIT",
            "quantity": quantity,
            "price": price,
            "timestamp": int(time.time() * 1000),
        }
        return self._send_request("POST", "/v1/orders", params=params)

    def cancel_order(self, order_id: str) -> dict:
        """Cancel an existing order."""
        params = {
            "orderId": order_id,
            "timestamp": int(time.time() * 1000),
        }
        return self._send_request("DELETE", f"/v1/orders/{order_id}", params=params)

    def get_order(self, order_id: str) -> dict:
        """Retrieve details of an existing order."""
        params = {
            "orderId": order_id,
            "timestamp": int(time.time() * 1000),
        }
        return self._send_request("GET", f"/v1/orders/{order_id}", params=params)

    def get_all_orders(self, symbol: str = None) -> dict:
        """Retrieve all orders, optionally filtered by symbol."""
        params = {
            "timestamp": int(time.time() * 1000),
        }
        if symbol:
            params["symbol"] = symbol
        return self._send_request("GET", "/v1/orders", params=params)
