
import time
import hmac
import json
import logging
from requests import Request, Session, Response
from typing import Optional, Dict, Any
from hashlib import sha256

# Configure logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

class PionexClient:
    _ENDPOINT = "https://api.pionex.com"
    TOP_ASSETS_PRECISION = {}

    def __init__(self, api_key=None, api_secret=None) -> None:
        self._api_key = api_key
        self._api_secret = api_secret
        self._session = Session()

    def _handle_request(self, request: Request, path: str) -> Optional[Response]:
        """Prepare and sign the request, then send it with retries."""
        prepared = request.prepare()
        query_str = f"{prepared.method}{path}?"
        if request.params:
            query_str += "&".join([f"{k}={v}" for k, v in sorted(request.params.items())])
        msg = f"{query_str}"
        if request.json:
            msg += f"{json.dumps(request.json)}"
        data = msg.strip("&").encode("utf-8")
        appsecret = self._api_secret.encode("utf-8")
        signature = hmac.new(appsecret, data, digestmod=sha256).hexdigest()

        # Add headers
        prepared.headers["PIONEX-KEY"] = self._api_key
        prepared.headers["PIONEX-SIGNATURE"] = signature
        prepared.headers["Content-Type"] = "application/json"

        # Retry logic
        retries = 3
        for attempt in range(retries):
            try:
                response = self._session.send(prepared)
                if response.status_code == 200:
                    logging.info(f"Request successful: {path}")
                    return response
                else:
                    logging.warning(f"Request failed with status {response.status_code}: {response.text}")
                    if "INVALID_TIMESTAMP" in response.text and attempt < retries - 1:
                        time.sleep(2 ** attempt)  # Exponential backoff
                        continue
                    response.raise_for_status()
            except Exception as e:
                logging.error(f"Error during request: {e}")
                if attempt < retries - 1:
                    time.sleep(2 ** attempt)  # Exponential backoff
                else:
                    raise
        return None

    def _validate_params(self, params: Dict[str, Any], required: Dict[str, str]) -> None:
        """Validate required and case-sensitive parameters."""
        for key, value_type in required.items():
            if key not in params:
                raise ValueError(f"Missing required parameter: {key}")
            if not isinstance(params[key], value_type):
                raise TypeError(f"Invalid type for parameter {key}: Expected {value_type}, got {type(params[key])}")

        # Example validation for intervals
        if "interval" in params and params["interval"] not in {"1M", "5M", "15M", "30M", "60M", "4H", "1D"}:
            raise ValueError(f"Invalid interval: {params['interval']}")

    def get_klines(self, symbol: str, interval: str, limit: int = 100) -> Optional[Response]:
        """Fetch historical candlestick data."""
        path = "/api/v1/market/klines"
        params = {"symbol": symbol, "interval": interval, "limit": limit}
        self._validate_params(params, {"symbol": str, "interval": str, "limit": int})

        request = Request("GET", f"{self._ENDPOINT}{path}", params=params)
        return self._handle_request(request, path)

    def get_account_balances(self) -> Optional[Response]:
        """Fetch account balances."""
        path = "/api/v1/account/balances"
        request = Request("GET", f"{self._ENDPOINT}{path}")
        return self._handle_request(request, path)
