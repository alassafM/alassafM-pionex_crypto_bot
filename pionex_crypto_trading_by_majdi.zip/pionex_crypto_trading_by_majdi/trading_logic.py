
def monitor_market_conditions(prices, bid_price, ask_price, config):
    """Monitors market conditions for trading signals."""
    signal = None
    if bid_price > config.get('threshold'):
        signal = 'BUY'
    elif ask_price < config.get('threshold'):
        signal = 'SELL'
    return signal
