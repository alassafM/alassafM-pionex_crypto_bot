import os
import websocket

def initialize_connections():
    api_key = os.getenv('API_KEY_1')
    api_secret = os.getenv('API_SECRET_1')

    if not api_key or not api_secret:
        raise ValueError("API keys are missing in the environment")

    # Assuming you're using Pionex WebSocket, set the URL
    ws_url = "wss://ws.pionex.com/wsPub"  # Use actual Pionex WebSocket URL

    ws = websocket.WebSocket()
    ws.connect(ws_url)

    # Send authentication message if needed
    ws.send(f'{{"api_key": "{api_key}", "api_secret": "{api_secret}"}}')

    return ws
