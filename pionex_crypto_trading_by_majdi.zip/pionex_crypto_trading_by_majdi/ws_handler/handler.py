from public_stream_handler import PublicStreamHandler
from private_stream_handler import PrivateStreamHandler
from dotenv import load_dotenv
import os
import time
import json
import hmac
import hashlib
import requests
from datetime import datetime

load_dotenv()  # Load .env variables

class FullWebSocketHandler:


    async def connect_public_handler(self):
        import aiohttp
        public_handler = PublicStreamHandler()
        await public_handler.connect()
        url = "wss://ws.pionex.com/wsPub"
        async with aiohttp.ClientSession() as session:
            try:
                ws = await session.ws_connect(url)
                print(f"Connected to {url}")

                # Subscribe to DEPTH topic
                payload = {
                    "op": "SUBSCRIBE",
                    "topic": "DEPTH",
                    "symbol": "BTC_USDT",
                    "limit": 5
                }
                await ws.send_json(payload)
                print(f"Subscribed to DEPTH")

                while True:
                    try:
                        msg = await asyncio.wait_for(ws.receive(), timeout=30)
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            print(f"Received message: {msg.data}")
                        elif msg.type == aiohttp.WSMsgType.BINARY:
                            decoded_data = json.loads(msg.data.decode("utf-8"))
                            if decoded_data.get("op") == "PING":
                                await ws.send_json({"op": "PONG", "timestamp": int(time.time() * 1000)})
                                print("PONG sent to server.")
                            else:
                                print(f"Received binary message: {decoded_data}")
                        elif msg.type in [aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.CLOSING]:
                            print("WebSocket closed by server.")
                            break
                        elif msg.type == aiohttp.WSMsgType.ERROR:
                            print(f"WebSocket error: {msg.data}")
                            break
                        else:
                            print(f"Other message type received: {msg.type}")
                    except asyncio.TimeoutError:
                        print("No messages received within timeout period. Continuing...")
            except Exception as e:
                print(f"WebSocket connection failed: {e}")
            finally:
                if ws:
                    await ws.close()
                print("WebSocket closed.")
                url = "wss://ws.pionex.com/wsPub"
        async with aiohttp.ClientSession() as session:
            try:
                ws = await session.ws_connect(url)
                print(f"Connected to {url}")

                payload = {
                    "op": "SUBSCRIBE",
                    "topic": "DEPTH",
                    "symbol": "BTC_USDT",
                    "limit": 5
                }
                await ws.send_json(payload)
                print("Subscribed to DEPTH")

                while True:
                    try:
                        msg = await asyncio.wait_for(ws.receive(), timeout=30)
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            print(f"Received message: {msg.data}")
                        elif msg.type == aiohttp.WSMsgType.BINARY:
                            decoded_data = json.loads(msg.data.decode("utf-8"))
                            if decoded_data.get("op") == "PING":
                                await ws.send_json({"op": "PONG", "timestamp": int(time.time() * 1000)})
                                print("PONG sent to server.")
                            else:
                                print(f"Received binary message: {decoded_data}")
                        elif msg.type in [aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.CLOSING]:
                            print("WebSocket closed by server.")
                            break
                        elif msg.type == aiohttp.WSMsgType.ERROR:
                            print(f"WebSocket error: {msg.data}")
                            break
                        else:
                            print(f"Other message type received: {msg.type}")
                    except asyncio.TimeoutError:
                        print("No messages received within timeout period. Continuing...")
            except Exception as e:
                print(f"WebSocket connection failed: {e}")
            finally:
             if ws:
                await ws.close()
            print("WebSocket closed.")

def __init__(self, api_key, secret_key, base_url, max_retries=5, rate_limit_threshold=3, heartbeat_interval=10):
    self.api_key = api_key or os.getenv('API_KEY_6')
    self.secret_key = secret_key or os.getenv('SECRET_KEY')
    self.base_url = base_url
    self.retry_count = 0
    self.max_retries = max_retries
    self.rate_limit_threshold = rate_limit_threshold
    self.heartbeat_interval = heartbeat_interval
    self.last_pong_received = None
    self.websocket = None  # Placeholder for WebSocket connection
    print(f"Debug: Loaded API_KEY_6 = {self.api_key}")

    if stream_type == "private" and not self.api_key:
        error_log = {
            "timestamp": datetime.now(datetime.timezone.utc).isoformat(),
            "context": "APIKeyValidation",
            "error_type": "MissingAPIKey",
        }
        with open("logs/errors.log", "a") as log_file:
            log_file.write(json.dumps(error_log) + "\n")
        raise ValueError("Missing API key for public_streams. Process halted.")

class FullWebSocketHandler:

    async def connect_public_handler(self):
        import aiohttp
        public_handler = PublicStreamHandler()
        await public_handler.connect()
        url = "wss://ws.pionex.com/wsPub"
        async with aiohttp.ClientSession() as session:
            try:
                ws = await session.ws_connect(url)
                print(f"Connected to {url}")

                # Subscribe to DEPTH topic
                payload = {
                    "op": "SUBSCRIBE",
                    "topic": "DEPTH",
                    "symbol": "BTC_USDT",
                    "limit": 5
                }
                await ws.send_json(payload)
                print(f"Subscribed to DEPTH")

                while True:
                    try:
                        msg = await asyncio.wait_for(ws.receive(), timeout=30)
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            print(f"Received message: {msg.data}")
                        elif msg.type == aiohttp.WSMsgType.BINARY:
                            decoded_data = json.loads(msg.data.decode("utf-8"))
                            if decoded_data.get("op") == "PING":
                                await ws.send_json({"op": "PONG", "timestamp": int(time.time() * 1000)})
                                print("PONG sent to server.")
                            else:
                                print(f"Received binary message: {decoded_data}")
                        elif msg.type in [aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.CLOSING]:
                            print("WebSocket closed by server.")
                            break
                        elif msg.type == aiohttp.WSMsgType.ERROR:
                            print(f"WebSocket error: {msg.data}")
                            break
                        else:
                            print(f"Other message type received: {msg.type}")
                    except asyncio.TimeoutError:
                        print("No messages received within timeout period. Continuing...")
            except Exception as e:
                print(f"WebSocket connection failed: {e}")
            finally:
                if ws:
                    await ws.close()
                print("WebSocket closed.")
                url = "wss://ws.pionex.com/wsPub"
        async with aiohttp.ClientSession() as session:
            try:
                ws = await session.ws_connect(url)
                print(f"Connected to {url}")

                payload = {
                    "op": "SUBSCRIBE",
                    "topic": "DEPTH",
                    "symbol": "BTC_USDT",
                    "limit": 5
                }
                await ws.send_json(payload)
                print("Subscribed to DEPTH")

                while True:
                    try:
                        msg = await asyncio.wait_for(ws.receive(), timeout=30)
                        if msg.type == aiohttp.WSMsgType.TEXT:
                            print(f"Received message: {msg.data}")
                        elif msg.type == aiohttp.WSMsgType.BINARY:
                            decoded_data = json.loads(msg.data.decode("utf-8"))
                            if decoded_data.get("op") == "PING":
                                await ws.send_json({"op": "PONG", "timestamp": int(time.time() * 1000)})
                                print("PONG sent to server.")
                            else:
                                print(f"Received binary message: {decoded_data}")
                        elif msg.type in [aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.CLOSING]:
                            print("WebSocket closed by server.")
                            break
                        elif msg.type == aiohttp.WSMsgType.ERROR:
                            print(f"WebSocket error: {msg.data}")
                            break
                        else:
                            print(f"Other message type received: {msg.type}")
                    except asyncio.TimeoutError:
                        print("No messages received within timeout period. Continuing...")
            except Exception as e:
                print(f"WebSocket connection failed: {e}")
            finally:
                if ws:
                    await ws.close()
                print("WebSocket closed.")
                """WebSocket handler with rate-limiting, handshake error handling, and heartbeat."""

    def __init__(self, api_key, secret_key, base_url, stream_type="public", max_retries=5, rate_limit_threshold=3, heartbeat_interval=10):
        load_dotenv()  # Load .env variables
        self.api_key = api_key or os.getenv('API_KEY_6')
        self.secret_key = secret_key or os.getenv('SECRET_KEY')
        self.base_url = base_url
        self.retry_count = 0
        self.max_retries = max_retries
        self.rate_limit_threshold = rate_limit_threshold
        self.heartbeat_interval = heartbeat_interval
        self.last_pong_received = None
        self.websocket = None  # Placeholder for WebSocket connection

        if stream_type == "private" and not self.api_key:
            error_log = {
                "timestamp": datetime.now(datetime.timezone.utc).isoformat(),
                "context": "APIKeyValidation",
                "error_type": "MissingAPIKey",
            }
            with open("logs/errors.log", "a") as log_file:
                log_file.write(json.dumps(error_log) + "\n")
            raise ValueError("Missing API key for public_streams. Process halted.")

    async def connect(self):
        private_handler = PrivateStreamHandler()
        await private_handler.connect()
        """Subscribe to the private BALANCE stream."""
        try:
            # Authenticate WebSocket connection for private topics
            timestamp = self.synchronize_timestamp()
            message = f"{timestamp}"
            signature = hmac.new(self.secret_key.encode(), message.encode(), hashlib.sha256).hexdigest()
            auth_payload = {
                "action": "auth",
                "apiKey": self.api_key,
                "timestamp": timestamp,
                "signature": signature
            }
            self.websocket.send(json.dumps(auth_payload))
            print("Authentication sent for private stream.")
                
            # Subscribe to BALANCE updates
            balance_subscription_payload = {
                "action": "subscribe",
                "channel": "BALANCE"
            }
            self.websocket.send(json.dumps(balance_subscription_payload))
            print("Subscription to BALANCE updates sent.")
    
        except Exception as e:
            error_log = {
                "timestamp": datetime.now(datetime.timezone.utc).isoformat(),
                "context": "PrivateStreamSubscription",
                "error_type": "SubscriptionError",
                "details": str(e)
            }
            with open("logs/errors.log", "a") as log_file:
                log_file.write(json.dumps(error_log) + "\n")
            raise ValueError("Failed to subscribe to private BALANCE stream.")
            
    def handle_balance_updates(self, balance_update):
        """Handle incoming BALANCE updates."""
        try:
            log_entry = {
                "timestamp": datetime.utcnow().isoformat() + 'Z',
                "account_id": balance_update.get("account_id", "unknown"),
                "asset": balance_update.get("asset", "unknown"),
                "available_balance": balance_update.get("available_balance", 0.0)
            }
            with open("logs/websocket.log", "a") as log_file:
                log_file.write(json.dumps(log_entry) + "\n")
            print("Logged balance update:", log_entry)
        except Exception as e:
            error_log = {
                "timestamp": datetime.utcnow().isoformat() + 'Z',
                "context": "BalanceUpdateHandler",
                "error_type": "LoggingError",
                "details": str(e)
            }
            with open("logs/errors.log", "a") as log_file:
                log_file.write(json.dumps(error_log) + "\n")
            raise ValueError("Error handling balance update.")
    
    def monitor_order_status(self):
        """Monitor real-time order status updates via WebSocket."""
        try:
            # Subscribe to ORDER topic for status updates
            order_subscription_payload = {
                "action": "subscribe",
                "channel": "ORDER"
            }
            self.websocket.send(json.dumps(order_subscription_payload))
            print("Subscription to ORDER updates sent.")

            # Handle incoming messages for order updates
            while True:
                message = self.websocket.recv()  # Blocking call to receive WebSocket messages
                order_update = json.loads(message)
                
                # Parse and log the order status update
                log_entry = {
                    "timestamp": datetime.now(datetime.timezone.utc).isoformat() + 'Z',
                    "order_id": order_update.get("order_id", "unknown"),
                    "symbol": order_update.get("symbol", "unknown"),
                    "status": order_update.get("status", "unknown"),
                    "quantity_filled": order_update.get("quantity_filled", 0.0),
                    "remaining_quantity": order_update.get("remaining_quantity", 0.0)
                }
                with open("logs/orders.log", "a") as log_file:
                    log_file.write(json.dumps(log_entry) + "\n")
                print("Logged order status update:", log_entry)
                    
        except Exception as e:
            # Log any errors related to WebSocket connection or message handling
            error_log = {
                "timestamp": datetime.now(datetime.timezone.utc).isoformat() + 'Z',
                "context": "OrderStatusMonitoring",
                "error_type": "WebSocketError",
                "details": str(e)
            }
            with open("logs/errors.log", "a") as log_file:
                log_file.write(json.dumps(error_log) + "\n")
            print(f"Error monitoring order status: {e}")
        """Establish WebSocket connection."""
        # Actual connection logic here (e.g., using websocket-client library)
        print("WebSocket connection established successfully.")

        try:
            timestamp = self.synchronize_timestamp()
            message = f"{timestamp}"
            signature = hmac.new(self.secret_key.encode(), message.encode(), hashlib.sha256).hexdigest()
            auth_payload = {
                "action": "auth",
                "apiKey": self.api_key,
                "timestamp": timestamp,
                "signature": signature
            }
            print("Sending authentication payload:", auth_payload)
            # Simulated response for invalid API key (replace with actual WebSocket send and response logic)
            simulated_response = {"status": "error", "message": "Invalid API key"}
            if simulated_response["status"] == "error" and "Invalid API key" in simulated_response["message"]:
                error_log = {
                    "timestamp": datetime.utcnow().isoformat() + 'Z',
                    "context": "APIKeyValidation",
                    "error_type": "InvalidAPIKey",
                    "details": "Invalid API key for public_streams."
                }
                with open("logs/errors.log", "a") as log_file:
                    log_file.write(json.dumps(error_log) + "\n")
                raise ValueError("Invalid API key for public_streams. Process halted.")
        except Exception as e:
            print(f"Authentication failed: {e}")

        """Authenticate WebSocket connection for private topics."""
        timestamp = self.synchronize_timestamp()
        message = f"{timestamp}"
        signature = hmac.new(self.secret_key.encode(), message.encode(), hashlib.sha256).hexdigest()
        auth_payload = {
            "action": "auth",
            "apiKey": self.api_key,
            "timestamp": timestamp,
            "signature": signature
        }
        print("Sending authentication payload:", auth_payload)
        # Send auth_payload via WebSocket here

    def synchronize_timestamp(self):
        """Synchronize timestamp using local system time as fallback."""
        try:
            # Uncomment the following if you find a valid API endpoint for timestamp synchronization:
            # response = requests.get("https://api.pionex.com/api/v1/market/klines")
            # response.raise_for_status()
            # server_time = int(response.json().get("server_time", time.time()))
            # return server_time
            print("Using local system time for synchronization.")
            return int(time.time())
        except Exception as e:
            print("Error synchronizing timestamp, using local time:", e)
            return int(time.time())


    def subscribe_to_balance(self):
        """Subscribe to BALANCE updates on private WebSocket."""
        balance_payload = {
            "action": "subscribe",
            "topic": "BALANCE"
        }
        print("Subscribing to BALANCE topic:", balance_payload)
        # Send balance_payload via WebSocket here

    def subscribe_to_topic(self, topic, symbol=None):
        """Subscribe to a specific topic for a given symbol."""
        subscription_payload = {"action": "subscribe", "topic": topic}
        if symbol:  # Add symbol only if required
            subscription_payload["symbol"] = symbol
        print(f"Subscribing to topic {topic} for symbol {symbol}: {subscription_payload}")
        # Send subscription_payload via WebSocket here

    def handle_balance_update(self, message):
        """Process and log BALANCE updates."""
        try:
            balance_data = json.loads(message)
            log_data = {
                "timestamp": time.time(),
                "account_id": balance_data.get("accountId"),
                "asset": balance_data.get("asset"),
                "available_balance": balance_data.get("availableBalance")
            }
            with open("logs/balance_updates.json", "a") as log_file:
                log_file.write(json.dumps(log_data) + "\n")
        except Exception as e:
            print("Error handling balance update:", e)

    def send_ping(self):
        """Send PING message to maintain connection."""
        print("PING sent to WebSocket server.")

    def handle_errors(self, error_type, details):
        """Enhanced error handling based on error type."""
        error_log = {
            "timestamp": time.time(),
            "error_type": error_type,
            "details": details,
            "suggested_action": self.suggest_action(error_type)
        }
        with open("logs/errors.log", "a") as log_file:
            log_file.write(json.dumps(error_log) + "\n")
        print("Error logged:", error_log)

    def suggest_action(self, error_type):
        """Provide suggested actions based on error type."""
        actions = {
            "SIGNATURE_LOST": "Reauthenticate and regenerate signature.",
            "RATE_LIMIT_EXCEEDED": "Throttle requests and wait before retrying.",
            "APIKEY_LOST": "Verify API key configuration and permissions."
        }
        return actions.get(error_type, "Unknown error type. Investigate further.")

    def close_connection(self):
        """Close WebSocket connection gracefully."""
        print("Closing WebSocket connection gracefully.")
