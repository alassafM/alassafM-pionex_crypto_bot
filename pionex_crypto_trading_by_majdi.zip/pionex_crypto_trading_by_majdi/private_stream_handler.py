
import asyncio
import aiohttp
import hmac
import hashlib
import json
import time
import os
from dotenv import load_dotenv

load_dotenv()

class PrivateStreamHandler:
    def __init__(self, url=os.getenv("PRIVATE_WEBSOCKET_URL"), api_key=os.getenv("API_KEY_2"), secret_key=os.getenv("API_SECRET_2")):
        self.url = url
        self.api_key = api_key
        self.secret_key = secret_key
        self.connection = None

    async def connect(self):
        """Connect to the private WebSocket stream."""
        try:
            session = aiohttp.ClientSession()
            self.connection = await session.ws_connect(self.url)
            print(f"Connected to {self.url}")
            await self.authenticate()
        except Exception as e:
            print(f"Failed to connect to private stream: {e}")

    async def authenticate(self):
        """Authenticate the private WebSocket connection."""
        try:
            timestamp = int(time.time() * 1000)
            message = f"{self.api_key}{timestamp}"
            signature = hmac.new(self.secret_key.encode(), message.encode(), hashlib.sha256).hexdigest()
            auth_payload = {
                "op": "auth",
                "args": [self.api_key, timestamp, signature]
            }
            await self.connection.send_json(auth_payload)
            print("Authentication request sent.")
        except Exception as e:
            print(f"Authentication failed: {e}")

    async def subscribe(self, topic, symbol=None):
        """Subscribe to a private stream topic."""
        try:
            if not self.connection:
                print("No active WebSocket connection. Call connect() first.")
                return
            payload = {
                "op": "subscribe",
                "topic": topic
            }
            if symbol:
                payload["symbol"] = symbol
            await self.connection.send_json(payload)
            print(f"Subscribed to topic {topic} for symbol {symbol}")
        except Exception as e:
            print(f"Failed to subscribe to {topic}: {e}")

    async def receive_messages(self):
        """Listen for messages from the WebSocket."""
        try:
            if not self.connection:
                print("No active WebSocket connection. Call connect() first.")
                return
            while True:
                msg = await self.connection.receive()
                if msg.type == aiohttp.WSMsgType.TEXT:
                    print(f"Message received: {msg.data}")
                elif msg.type == aiohttp.WSMsgType.ERROR:
                    print(f"Error received: {msg.data}")
                elif msg.type == aiohttp.WSMsgType.CLOSED:
                    print("WebSocket connection closed by server.")
                    break
        except Exception as e:
            print(f"Error while receiving messages: {e}")

    async def disconnect(self):
        """Disconnect the WebSocket connection."""
        try:
            if self.connection:
                await self.connection.close()
                print("Disconnected from WebSocket.")
        except Exception as e:
            print(f"Failed to disconnect: {e}")
