
# Simulate missing primary API key for 'public_streams'
API_KEYS['public_streams'] = None

# Test failover logic
test_api_key = get_api_key_with_failover('public_streams')
if test_api_key:
    log_event("FailoverTest", "Success", f"Failover mechanism returned backup key: {test_api_key}")
else:
    log_error("FailoverTest", "Failure", "Failover mechanism failed to provide a valid key.")
