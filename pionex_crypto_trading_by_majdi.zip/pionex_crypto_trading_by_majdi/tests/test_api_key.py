from dotenv import load_dotenv
import os
import requests
import json
from datetime import datetime
import hmac
import hashlib

# Load environment variables
load_dotenv()

# Test API Key
api_key = os.getenv("API_KEY_6")
secret_key = os.getenv("API_SECRET_6")

if not api_key or not secret_key:
    print("API_KEY_6 or API_SECRET_6 is missing from the environment.")
    exit()

# Simulate authentication payload
def generate_signature(secret, message):
    return hmac.new(secret.encode(), message.encode(), hashlib.sha256).hexdigest()

try:
    # Simulate timestamp and signature generation
    timestamp = int(datetime.utcnow().timestamp())
    message = f"{timestamp}"
    signature = generate_signature(secret_key, message)

    # Print the payload to debug
    auth_payload = {
        "action": "auth",
        "apiKey": api_key,
        "timestamp": timestamp,
        "signature": signature
    }
    print(f"Authentication Payload: {auth_payload}")

    # Make a test request to the WebSocket authentication endpoint
    # Replace with Pionex equivalent REST endpoint for testing
    print("Simulating authentication...")
    # Normally this would connect to WebSocket or REST
    print("Payload simulation successful.")

except Exception as e:
    print(f"Error during test: {e}")
