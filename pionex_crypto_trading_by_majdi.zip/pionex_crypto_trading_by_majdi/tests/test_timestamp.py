import requests
from datetime import datetime

# Pionex API Base URL
BASE_URL = "https://api.pionex.com"

# Correct endpoint for klines
KLINES_ENDPOINT = "/api/v1/market/klines"

def get_server_time():
    # Correct parameters based on Pionex API documentation
    params = {
        "symbol": "BTC_USDT",  # Example trading pair
        "interval": "1M",      # Correct interval value (case-sensitive)
        "limit": 1             # Fetch one data point
    }
    try:
        response = requests.get(BASE_URL + KLINES_ENDPOINT, params=params)
        response_json = response.json()  # Parse response JSON
        print(f"Full API Response: {response_json}")

        if response.status_code == 200 and response_json.get('result'):
            kline = response_json['data']['klines'][0]
            server_time = kline['time']
            print(f"Using Server Time (ms): {server_time}")
            return int(server_time / 1000)  # Convert ms to seconds
        else:
            print(f"Failed to fetch server time: {response_json.get('message', 'Unknown error')}")
            return None
    except Exception as e:
        print(f"Error fetching server time: {e}")
        return None

# Fetch server time and print it
server_time = get_server_time()

if server_time:
    print(f"Server Time (s): {server_time}")
else:
    print("Failed to fetch server time.")
