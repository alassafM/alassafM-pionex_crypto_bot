
import unittest
from unittest.mock import patch, MagicMock
from websocket import WebSocketApp

class TestWebSocket(unittest.TestCase):

    @patch("websocket.WebSocketApp")
    def test_websocket_connection(self, mock_ws_app):
        mock_ws_instance = MagicMock()
        mock_ws_app.return_value = mock_ws_instance
        from ws_handler.handler import WebSocketHandler

        handler = WebSocketHandler("wss://ws.pionex.com", "api_key", "api_secret")
        handler.connect()
        mock_ws_instance.run_forever.assert_called()

    def test_ping_pong_handling(self):
        from ws_handler.handler import WebSocketHandler
        handler = WebSocketHandler("wss://ws.pionex.com", "api_key", "api_secret")

        mock_ws = MagicMock()
        mock_ws.send = MagicMock()
        handler.on_message(mock_ws, '{"op": "PING"}')
        mock_ws.send.assert_called_with('{"op": "PONG", "timestamp": 123456789}')

    @patch("websocket.WebSocketApp")
    def test_trade_subscription(self, mock_ws_app):
        mock_ws_instance = MagicMock()
        mock_ws_app.return_value = mock_ws_instance
        from ws_handler.handler import WebSocketHandler

        handler = WebSocketHandler("wss://ws.pionex.com", "api_key", "api_secret")
        handler.on_open(mock_ws_instance)
        mock_ws_instance.send.assert_any_call('{"op": "SUBSCRIBE", "topic": "TRADE", "symbol": "BTC_USDT"}')

if __name__ == "__main__":
    unittest.main()
