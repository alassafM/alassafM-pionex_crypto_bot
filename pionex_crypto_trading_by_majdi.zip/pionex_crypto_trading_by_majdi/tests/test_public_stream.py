import aiohttp
import asyncio
import json

async def test_public_stream():
    url = "wss://ws.pionex.com/wsPub"
    topics = ["DEPTH"]  # Testing DEPTH topic

    async with aiohttp.ClientSession() as session:
        ws = None
        try:
            ws = await session.ws_connect(url)
            print(f"Connected to {url}")
            
            # Subscribe to DEPTH topic with the required limit parameter
            for topic in topics:
                payload = {
                    "op": "SUBSCRIBE",
                    "topic": topic,
                    "symbol": "BTC_USDT",
                    "limit": 5  # Adjust the limit as needed
                }
                await ws.send_json(payload)
                print(f"Subscribed to: {topic}")

            # Receive messages with extended timeout
            while True:
                ws = None
        try:
                    msg = await asyncio.wait_for(ws.receive(), timeout=30)  # Extended timeout to 30 seconds
                    if msg.type == aiohttp.WSMsgType.TEXT:
                        print(f"Received text message: {msg.data}")
                    elif msg.type == aiohttp.WSMsgType.BINARY:
                        decoded_data = json.loads(msg.data.decode("utf-8"))
                        if decoded_data.get("op") == "PING":
                            await ws.send_json({"op": "PONG", "timestamp": int(time.time() * 1000)})
                            print("PONG sent to server.")
                        else:
                            print(f"Received binary message: {decoded_data}")
                    elif msg.type in [aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.CLOSING]:
                        print("WebSocket closed by server.")
                        break
                    elif msg.type == aiohttp.WSMsgType.ERROR:
                        print(f"WebSocket error: {msg.data}")
                        break
                    else:
                        print(f"Other message type received: {msg.type}")
                except asyncio.TimeoutError:
                    print("No messages received within timeout period. Continuing...")
        except asyncio.CancelledError:
            print("Task was cancelled. Exiting...")
        finally:
            if ws:
                await ws.close()
                print('WebSocket connection closed.')
        except Exception as e:
            print(f"Connection failed: {e}")
        finally:
            if ws:
                await ws.close()
            print("WebSocket closed.")

# Run the test
try:
    asyncio.run(test_public_stream())
except KeyboardInterrupt:
    print("Test interrupted manually. Exiting...")
