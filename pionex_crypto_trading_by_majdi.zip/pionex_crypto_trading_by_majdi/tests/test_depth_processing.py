import aiohttp
import asyncio
import json

async def test_public_stream():
    url = "wss://ws.pionex.com/wsPub"
    topics = ["DEPTH"]

    async with aiohttp.ClientSession() as session:
        try:
            ws = await session.ws_connect(url)
            print(f"Connected to {url}")

            # Subscribe to DEPTH topic
            for topic in topics:
                payload = {
                    "op": "SUBSCRIBE",
                    "topic": topic,
                    "symbol": "BTC_USDT",
                    "limit": 5
                }
                await ws.send_json(payload)
                print(f"Subscribed to: {topic}")

            # Process incoming messages
            while True:
                msg = await asyncio.wait_for(ws.receive(), timeout=30)
                if msg.type == aiohttp.WSMsgType.BINARY:
                    decoded_data = json.loads(msg.data.decode("utf-8"))
                    if "data" in decoded_data:
                        bids = decoded_data["data"]["bids"]
                        asks = decoded_data["data"]["asks"]

                        # Calculate spread and total volumes
                        highest_bid = float(bids[0][0])
                        lowest_ask = float(asks[0][0])
                        spread = lowest_ask - highest_bid
                        total_bids_volume = sum(float(bid[1]) for bid in bids[:5])
                        total_asks_volume = sum(float(ask[1]) for ask in asks[:5])

                        # Log results
                        processed_data = {
                            "spread": spread,
                            "total_bids_volume": total_bids_volume,
                            "total_asks_volume": total_asks_volume
                        }
                        print(f"Processed Data: {processed_data}")

                        # Write to file
                        with open("order_book_analysis.json", "a") as f:
                            json.dump(processed_data, f)
                            f.write("\n")
                elif msg.type in [aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.CLOSING]:
                    print("WebSocket closed by server.")
                    break
                elif msg.type == aiohttp.WSMsgType.ERROR:
                    print(f"WebSocket error: {msg.data}")
                    break
        except asyncio.TimeoutError:
            print("No messages received within timeout period. Continuing...")
        except Exception as e:
            print(f"Connection failed: {e}")
        finally:
            if ws:
                await ws.close()
            print("WebSocket closed.")

# Run the test
try:
    asyncio.run(test_public_stream())
except KeyboardInterrupt:
    print("Test interrupted manually. Exiting...")
