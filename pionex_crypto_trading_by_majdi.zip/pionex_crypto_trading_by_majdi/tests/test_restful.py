
import unittest
from unittest.mock import patch, MagicMock
from ..restful.client import PionexClient

class TestRestful(unittest.TestCase):

    @patch("restful.client.PionexClient.place_order")
    def test_place_order(self, mock_place_order):
        mock_place_order.return_value = {"orderId": "12345"}
        client = PionexClient("api_key", "api_secret")
        response = client.place_order("BTC_USDT", "BUY", 0.01, 30000)
        self.assertEqual(response["orderId"], "12345")

    @patch("restful.client.PionexClient.fetch_balance")
    def test_fetch_balance(self, mock_fetch_balance):
        mock_fetch_balance.return_value = {
            "data": [
                {"asset": "BTC", "available": "1.5"},
                {"asset": "USDT", "available": "1000"}
            ]
        }
        client = PionexClient("api_key", "api_secret")
        response = client.fetch_balance()
        self.assertIn("BTC", [item["asset"] for item in response["data"]])

    @patch("restful.client.PionexClient.fetch_klines")
    def test_fetch_klines(self, mock_fetch_klines):
        mock_fetch_klines.return_value = {
            "data": [
                {"time": 123456789, "open": 100, "high": 105, "low": 95, "close": 100},
                {"time": 123456790, "open": 101, "high": 106, "low": 96, "close": 101}
            ]
        }
        client = PionexClient("api_key", "api_secret")
        response = client.fetch_klines("BTC_USDT", "1M", 2)
        self.assertEqual(len(response["data"]), 2)

if __name__ == "__main__":
    unittest.main()
