
# Majdi Crypto Project

## Folder Structure

```
majdi_crypto/
├── majdi_bot.py          # Main orchestrator script
├── .env                  # Environment file for sensitive configurations (placeholder)
├── README.md             # Project documentation
├── requirements.txt      # Dependencies
├── config/
│   ├── config.json       # Runtime parameters like trade sizes and risk levels
├── logs/                 # Logs for troubleshooting and debugging
├── strategies/
│   ├── validations.py    # Parameter validation logic
├── restful/
│   ├── client.py         # RESTful client logic with time syncing and timestamp handling
├── websocket/
│   ├── handler.py        # WebSocket handling logic
├── tests/
│   ├── test_restful.py   # Tests for RESTful client functionality
│   ├── test_websocket.py # Tests for WebSocket handling
```

## New Features Added

1. **majdi_bot.py**:
   - Centralized orchestration for the bot, including scheduling tasks, syncing time, and WebSocket integration.

2. **restful/client.py**:
   - Added `sync_time()` method to calculate `time_offset` for accurate timestamps.
   - Updated GET, POST, and DELETE methods to use adjusted timestamps.

3. **websocket/handler.py**:
   - Implemented connection logic for public and private WebSocket streams.
   - Added subscription and unsubscription to WebSocket topics.
   - Included reconnection and heartbeat handling.

4. **strategies/validations.py**:
   - Validations for symbols, intervals, and order parameters.
   - Centralized validation logic for RESTful API and WebSocket topics.

5. **Tests**:
   - `test_restful.py`: Tests for timestamp handling and private API requests.
   - `test_websocket.py`: Tests for WebSocket connections, subscriptions, and reconnection logic.

6. **Supporting Files**:
   - `.env`: Placeholder file for API keys and sensitive configurations.
   - `config.json`: Contains runtime configuration parameters.
   - `requirements.txt`: Lists Python dependencies required for the project.

## Logs
- Logs are saved in the `logs/` folder for API, WebSocket, and strategy validation activities.

## Notes
- Ensure `.env` is updated with real credentials before running the project.
- Install dependencies using `pip install -r requirements.txt`.

## Recent Updates

### 1. Rate-Limit Handling
- Dynamically adjusts retry delays based on the `x-ratelimit-tokens` header provided by the server.
- Prevents overwhelming the server during retries by implementing exponential backoff.

### 2. Comprehensive Logging
- Errors and events are logged in structured JSON format.
- Log files: 
  - `logs/errors.log`: Captures all errors with timestamps and detailed context.
  - `logs/websocket.log`: Captures WebSocket events like connections, disconnections, and subscription updates.

### 3. WebSocket Subscription Logic
- Subscribes to the `BALANCE` topic automatically upon connection.
- Logs subscription success or failure.

### 4. Risk Management
- Calculates trade sizes dynamically based on the latest balance and risk percentage.
- Includes validation to ensure values are greater than zero.

### 5. Config File Validation
- Validates the `config.json` file at startup to ensure all required fields are present and correctly typed.
- Fields validated:
  - `max_trade_risk` (float)
  - `daily_loss_limit` (float)
  - `api_key` (string)
  - `secret_key` (string)
- Logs success or failure.

### File Structure Overview
```
majdi_crypto_trading/
├── config/
│   └── config.json
├── logs/
│   ├── errors.log
│   └── websocket.log
├── strategies/
│   └── calculations.py
├── utilities.py
├── majdi_bot.py
└── README.md
```

## Testing and Debugging
- Ensure environment variables are correctly set in `.env`.
- Check `logs/` directory for detailed debugging information.
- Use `tests/` folder for unit testing new features.
