import json

def log_json(file_path, log_data):
    """Logs data to a JSON file."""
    with open(file_path, 'a') as file:
        json.dump(log_data, file)
        file.write('\n')

def log_error(file_path, error_message):
    """Logs an error message to a JSON file."""
    log_data = {"error": error_message}
    log_json(file_path, log_data)

def log_event(log_file, event_type, details):
    """Logs an event to a JSON file."""
    log_data = {
        "event_type": event_type,
        "details": details
    }
    log_json(log_file, log_data)
