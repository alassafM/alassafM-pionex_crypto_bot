
import logging
import numpy as np
from typing import List, Dict
from scalping_strategy import ScalpingStrategy

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class BacktestingFramework:
    def __init__(self, strategy: ScalpingStrategy, historical_data: List[float]):
        self.strategy = strategy
        self.historical_data = historical_data
        self.trades = []

    def run(self):
        """Run the backtesting simulation."""
        for i in range(len(self.historical_data)):
            if i < max(self.strategy.rsi_period, self.strategy.bollinger_period):
                continue

            # Extract relevant price window for strategy
            price_window = self.historical_data[:i + 1]

            # Execute the strategy
            trade_signal = self.strategy.execute_trade(price_window)

            if trade_signal:
                self.trades.append(trade_signal)

    def calculate_metrics(self) -> Dict[str, float]:
        """Calculate performance metrics for the backtesting."""
        if not self.trades:
            logging.warning("No trades executed during backtesting.")
            return {}

        profits = []
        for trade in self.trades:
            if trade["action"] == "BUY":
                profit = trade["take_profit"] - trade["entry"]
            elif trade["action"] == "SELL":
                profit = trade["entry"] - trade["take_profit"]
            else:
                profit = 0
            profits.append(profit)

        total_profit = np.sum(profits)
        win_rate = np.mean([p > 0 for p in profits]) * 100
        sharpe_ratio = total_profit / (np.std(profits) if np.std(profits) > 0 else 1)

        return {
            "total_profit": total_profit,
            "win_rate": win_rate,
            "sharpe_ratio": sharpe_ratio
        }

# Example usage
if __name__ == "__main__":
    # Example historical data (replace with real data)
    historical_prices = [100 + np.sin(i / 10) * 5 for i in range(300)]

    # Initialize the strategy
    strategy = ScalpingStrategy(
        account_balance=1000,
        stop_loss_pct=0.5,
        take_profit_pct=1,
        rsi_period=14,
        bollinger_period=20
    )

    # Run the backtesting framework
    backtesting = BacktestingFramework(strategy, historical_prices)
    backtesting.run()
    metrics = backtesting.calculate_metrics()
    logging.info(f"Backtesting Metrics: {metrics}")
