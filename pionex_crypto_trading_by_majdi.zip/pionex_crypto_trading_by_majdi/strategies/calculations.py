
# Function to calculate trade size based on risk percentage and available balance
def calculate_trade_size(balance, risk_percentage):
    try:
        if balance <= 0 or risk_percentage <= 0:
            raise ValueError("Balance and risk percentage must be greater than zero.")
        trade_size = (balance * risk_percentage) / 100
        log_event("RiskManagement", "TradeSizeCalculation", f"Calculated trade size: {trade_size}")
        return trade_size
    except Exception as e:
        log_error("RiskManagement", "CalculationError", str(e))
        return 0

import numpy as np

def calculate_rsi(prices, period=14):
    delta = np.diff(prices)
    gain = np.maximum(delta, 0)
    loss = -np.minimum(delta, 0)
    avg_gain = np.convolve(gain, np.ones(period, dtype=int), 'valid') / period
    avg_loss = np.convolve(loss, np.ones(period, dtype=int), 'valid') / period
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def calculate_moving_average(prices, period=14):
    return np.convolve(prices, np.ones(period, dtype=int), 'valid') / period

def calculate_bollinger_bands(prices, period=20, std_dev_factor=2):
    ma = calculate_moving_average(prices, period)
    rolling_std = np.std([prices[i:i + period] for i in range(len(prices) - period + 1)], axis=1)
    upper_band = ma + std_dev_factor * rolling_std
    lower_band = ma - std_dev_factor * rolling_std
    return upper_band, lower_band

def calculate_macd(prices, fast_period=12, slow_period=26, signal_period=9):
    ema_fast = calculate_moving_average(prices, fast_period)
    ema_slow = calculate_moving_average(prices, slow_period)
    macd_line = ema_fast - ema_slow[:len(ema_fast)]
    signal_line = calculate_moving_average(macd_line, signal_period)
    histogram = macd_line[:len(signal_line)] - signal_line
    return macd_line, signal_line, histogram

def calculate_parabolic_sar(highs, lows, af=0.02, max_af=0.2):
    sar = [lows[0]]
    for i in range(1, len(highs)):
        prev_sar = sar[-1]
        sar.append(min(prev_sar + af * (highs[i - 1] - prev_sar), highs[i]))
    return sar

def calculate_stochastic_oscillator(prices, period=14):
    low_min = np.min([prices[i:i + period] for i in range(len(prices) - period + 1)], axis=1)
    high_max = np.max([prices[i:i + period] for i in range(len(prices) - period + 1)], axis=1)
    stochastic = 100 * (prices[-len(low_min):] - low_min) / (high_max - low_min)
    return stochastic
