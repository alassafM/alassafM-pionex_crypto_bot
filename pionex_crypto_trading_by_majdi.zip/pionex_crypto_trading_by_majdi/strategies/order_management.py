
# Order management logic for trading strategies

def place_sell_order(client, symbol, quantity, price):
    order = client.place_order(symbol=symbol, side="SELL", quantity=quantity, price=price)
    if order.get("status") != "success":
        raise RuntimeError(f"Failed to place sell order: {order}")
    return order

def place_order(client, symbol, side, quantity, price):
    order = client.place_order(symbol=symbol, side=side, quantity=quantity, price=price)
    if order.get("status") != "success":
        raise RuntimeError(f"Failed to place {side} order: {order}")
    return order

def should_buy(current_price, lower_band):
    return current_price < lower_band

def should_sell(current_price, upper_band):
    return current_price > upper_band
