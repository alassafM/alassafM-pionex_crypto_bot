
# Configuration for trading asset settings

# Minimum trade sizes for top assets
TOP_ASSETS_MIN_TRADE_SIZE = {
    "ETH_USDT": 0.00001,
    "BTC_USDT": 0.000001,
    "BNB_USDT": 0.0001,
    "XRP_USDT": 0.1,
    "ADA_USDT": 0.1,
    "SOL_USDT": 0.01,
    "LTC_USDT": 0.001,
    "DOT_USDT": 0.01,
    "AVAX_USDT": 0.001,
    "LINK_USDT": 0.01,
    "TRX_USDT": 1,
    "FIL_USDT": 0.0001,
    "UNI_USDT": 0.01,
    "AAVE_USDT": 0.001
}

# Precision values for top assets
TOP_ASSETS_PRECISION = {
    "ETH_USDT": 5,
    "BTC_USDT": 6,
    "BNB_USDT": 4,
    "XRP_USDT": 1,
    "ADA_USDT": 1,
    "SOL_USDT": 2,
    "LTC_USDT": 3,
    "DOT_USDT": 2,
    "AVAX_USDT": 3,
    "LINK_USDT": 2,
    "TRX_USDT": 0,
    "FIL_USDT": 4,
    "UNI_USDT": 2,
    "AAVE_USDT": 3
}
