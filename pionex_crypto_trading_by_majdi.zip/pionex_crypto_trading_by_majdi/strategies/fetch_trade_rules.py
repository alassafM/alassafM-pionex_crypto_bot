import json
import requests
import os
from datetime import datetime
import logging

# ==================== Section 1: Logging Configuration ====================
logging.basicConfig(
    filename="fetch_and_cache_trade_rules.log",  # Log file name
    level=logging.DEBUG,  # Log level (DEBUG captures all levels)
    format="%(asctime)s - %(levelname)s - %(message)s",  # Log format
)

logging.info("Starting fetch_and_cache_trade_rules script...")

# ==================== Section 2: Constants ====================
CACHE_FILE = "trade_rules.json"

# ==================== Section 3: Fetching Trade Rules ====================
def validate_trade_rule(symbol, rule):
    """Validate a single trade rule for completeness and correctness."""
    try:
        min_trade_size = float(rule.get("minTradeSize", 0))
        amount_precision = int(rule.get("amountPrecision", -1))

        if min_trade_size <= 0 or not (0 <= amount_precision <= 8):
            logging.warning(f"Invalid trade rule for {symbol}: {rule}")
            return False
        return True
    except (ValueError, TypeError):
        logging.error(f"Error validating trade rule for {symbol}: {rule}")
        return False


def fetch_trade_rules():
    """Fetch trading rules dynamically from Pionex and save to cache."""
    logging.info("Fetching trade rules from Pionex API...")
    url = "https://api.pionex.com/api/v1/common/symbols"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            logging.info("Successfully fetched trade rules from Pionex API.")
            data = response.json()

            symbol_rules = {}
            for item in data["data"]["symbols"]:
                symbol = item["symbol"]
                rule = {
                    "minTradeSize": float(item["minTradeSize"]),
                    "amountPrecision": int(item["amountPrecision"]),
                }
                if validate_trade_rule(symbol, rule):
                    symbol_rules[symbol] = rule

            save_to_cache(symbol_rules)
            logging.info(f"Validated and saved {len(symbol_rules)} trading pairs.")
            return symbol_rules
        else:
            logging.error(f"Failed to fetch trade rules: HTTP {response.status_code}")
            return {}
    except Exception as e:
        logging.error(f"Exception during API fetch: {e}")
        return {}

# ==================== Section 4: Cache Management ====================
def save_to_cache(data):
    """Save trade rules to a local JSON cache."""
    try:
        with open(CACHE_FILE, "w") as f:
            json.dump(data, f, indent=4)
        logging.info(f"Trade rules successfully saved to {CACHE_FILE} with {len(data)} pairs.")
    except Exception as e:
        logging.error(f"Failed to save trade rules to cache: {e}")

def load_cached_trade_rules():
    """Load cached trade rules from local file."""
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, "r") as f:
                symbol_rules = json.load(f)
                logging.info(f"Loaded cached trade rules from {CACHE_FILE}.")
                return symbol_rules
        except Exception as e:
            logging.error(f"Failed to load cached trade rules: {e}")
    else:
        logging.warning(f"No cache file found. Fetching trade rules dynamically.")
        return fetch_trade_rules()

def is_cache_outdated():
    """Check if the cache file is older than 24 hours."""
    if os.path.exists(CACHE_FILE):
        last_modified = os.path.getmtime(CACHE_FILE)
        cache_age = (datetime.now() - datetime.fromtimestamp(last_modified)).total_seconds()
        logging.info(f"Cache age: {cache_age / 3600:.2f} hours.")
        return cache_age > 86400  # 24 hours in seconds
    return True

# ==================== Section 5: Main Execution ====================
if __name__ == "__main__":
    try:
        # Check if cache is outdated
        if is_cache_outdated():
            logging.info("Cache is outdated. Fetching fresh trade rules.")
            trade_rules = fetch_trade_rules()
        else:
            logging.info("Cache is up-to-date. Loading cached trade rules.")
            trade_rules = load_cached_trade_rules()

        # Log summary of fetched or loaded trade rules
        if trade_rules:
            logging.info(f"Fetched or loaded trade rules for {len(trade_rules)} trading pairs.")
        else:
            logging.warning("No trade rules available.")

    except Exception as e:
        logging.error(f"Unexpected error during execution: {e}")
