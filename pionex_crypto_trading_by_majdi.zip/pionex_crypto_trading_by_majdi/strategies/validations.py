
# Validation logic for trading strategies

def pre_trade_validation(asset, trade_size, min_trade_size):
    if trade_size < min_trade_size:
        raise ValueError(f"Trade size {trade_size} is less than the minimum {min_trade_size} for {asset}.")
    return True

def simulate_trade_validation(asset, price, trade_size, balance):
    cost = price * trade_size
    if cost > balance:
        raise ValueError(f"Not enough balance to trade {trade_size} {asset} at {price}.")
    return True

def validate_order_params(order_params):
    required_fields = ["symbol", "side", "quantity", "price"]
    for field in required_fields:
        if field not in order_params:
            raise ValueError(f"Missing required field: {field}")
    return True

def round_trade_quantity(quantity, precision):
    return round(quantity, precision)

def fetch_asset_precision(asset, precision_mapping):
    return precision_mapping.get(asset, None)

def fetch_min_trade_size_static(asset, min_trade_mapping):
    return min_trade_mapping.get(asset, None)
