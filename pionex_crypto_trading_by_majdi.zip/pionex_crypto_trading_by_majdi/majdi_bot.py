
import asyncio

def run_async_compatible(coro):
    try:
        loop = asyncio.get_running_loop()
        # If loop is running, create and return a task
        task = asyncio.ensure_future(coro)
        return loop.run_until_complete(task)
    except RuntimeError:
        # No running loop, so use asyncio.run
        return asyncio.run(coro)


def run_async_compatible(coro):
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:  # No running loop
        loop = None

    if loop:
        return asyncio.ensure_future(coro)
    else:
        return asyncio.run(coro)

import asyncio
from dotenv import load_dotenv
import os
from strategies import enhanced_scalping_strategy
from strategies.scalping_selling import place_sell_order
load_dotenv()
import json
import time
import logging
import hmac
import hashlib
from pathlib import Path
from public_stream_handler import PublicStreamHandler
from private_stream_handler import PrivateStreamHandler

# Task-specific API key assignments
API_KEYS = {
    "public_streams": os.getenv("API_KEY_1"),
    "private_streams": os.getenv("API_KEY_2"),
    "order_management": os.getenv("API_KEY_3"),
    "risk_management": os.getenv("API_KEY_4"),
    "backup": os.getenv("API_KEY_5")
}

# Function to retrieve the appropriate API key for a given task
from utilities import get_api_key_with_failover
from logging_utilities import log_error


def get_api_key(task_name):
    """Retrieves the API key for a specific task using failover logic."""
    return get_api_key_with_failover(task_name, API_KEYS)
    
def log_structured_json(file_path, log_data):
    with open(file_path, "a") as log_file:
        log_file.write(json.dumps(log_data) + "\n")

# Enhanced error logging function
def log_error_details(event_type, details, context, error_type, error_log_path):
    log_data = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()),
        "event": event_type,
        "details": details,
        "context": context,
        "error_type": error_type
    }
    log_json(error_log_path, log_data)

# Enhanced event logging function

    log_data = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()),
        "event": event_type,
        "details": details,
        "context": context
    }
    log_json(websocket_log_path, log_data)

# Function to handle rate limit based on server-provided headers
from error_handling import handle_rate_limit

def handle_rate_limit(headers):
    rate_limit_tokens = headers.get('x-ratelimit-tokens')
    if rate_limit_tokens:
        rate_limit_tokens = int(rate_limit_tokens)
        if rate_limit_tokens < 3:
            delay = 5 * (3 - rate_limit_tokens)  # Add delay based on remaining tokens
            logging.warning(f"Rate limit approaching. Delaying next retry by {delay} seconds.")
            time.sleep(delay)
    else:
        logging.debug("Rate limit tokens not found in headers.")

# Exponential backoff function
from utilities import exponential_backoff

def exponential_backoff(attempt, base=2, cap=60):
    return min(cap, base ** attempt)

# Function to handle WebSocket errors gracefully
from error_handling import handle_websocket_error

def handle_websocket_error(attempt, max_retries=5):
    if attempt >= max_retries:
        logging.error("Maximum retry attempts reached. Exiting...")
        return False
    delay = exponential_backoff(attempt)
    logging.warning(f"WebSocket error occurred. Retrying in {delay} seconds...")
    time.sleep(delay)
    return True

# Function to verify signature logic
    signature = hmac.new(secret_key.encode(), payload.encode(), hashlib.sha256).hexdigest()
    logging.debug(f"Generated payload: {payload}, signature: {signature}")
    return signature

# Load environment variables
dotenv_path = Path(".env")

# Dynamically set the log directory and paths
script_dir = os.path.dirname(os.path.abspath(__file__))
log_dir = os.path.join(script_dir, "logs")
os.makedirs(log_dir, exist_ok=True)

# Define log file paths
error_log_path = os.path.join(log_dir, "errors.log")
websocket_log_path = os.path.join(log_dir, "websocket.log")
market_monitoring_log_path = os.path.join(log_dir, "market_monitoring.json")

# Set up error logging
error_logger = logging.getLogger("error_logger")
error_logger.setLevel(logging.ERROR)
error_handler = logging.FileHandler(error_log_path)
error_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
error_logger.addHandler(error_handler)

# Set up event logging
event_logger = logging.getLogger("event_logger")
event_logger.setLevel(logging.INFO)
event_handler = logging.FileHandler(websocket_log_path)
event_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
event_logger.addHandler(event_handler)

from trading_logic import monitor_market_conditions

# Fetch strategy signals
signal = enhanced_scalping_strategy()

# Log strategy output
print("DEBUG: Parameters for log_event: event_type, event_details, context"); log_event("Strategy Signal", {"signal": signal}, "Trading", market_monitoring_log_path)

# Execute sell orders if signal indicates a sell action
if signal.get("action") == "sell":
    symbol = signal.get("symbol", "BTC_USDT")
    quantity = signal.get("quantity", 0.01)  # Default quantity for testing
    place_sell_order(symbol, quantity)

    # Check for volatility and bid-ask spread
    volatility_threshold = config.get('volatility_threshold', 0.05)
    spread_threshold = config.get('spread_threshold', 0.02)

def check_price_volatility(prices, volatility_threshold, market_monitoring_log_path):
    # Check for price volatility
    if len(prices) >= 2:
        price_change = abs((prices[-1] - prices[0]) / prices[0])
        if price_change >= volatility_threshold:
            print("DEBUG: Parameters for log_event: event_type, event_details, context"); log_event("Volatility Detected", {
                "price_change_percentage": price_change,
                "prices": prices
            }, "Market Monitoring", market_monitoring_log_path)
            print(f"Volatility detected: {price_change * 100:.2f}%")
            return True
    return False

# Check bid-ask spread
def check_bid_ask_spread(bid_price, ask_price, spread_threshold, market_monitoring_log_path):
    if bid_price and ask_price:
        spread = (ask_price - bid_price) / bid_price
        if spread >= spread_threshold:
            print("DEBUG: Parameters for log_event: event_type, event_details, context"); log_event("High Spread Detected", {
                "bid_price": bid_price,
                "ask_price": ask_price,
                "spread_percentage": spread
            }, "Market Monitoring", market_monitoring_log_path)
            print(f"High bid-ask spread detected: {spread * 100:.2f}%")
            return True
    return False

def initialize_connections():
    """Initialize public and private WebSocket connections."""
    # URLs for public and private WebSocket endpoints
    public_ws_url = os.getenv("PUBLIC_WEBSOCKET_URL")
    private_ws_url = os.getenv("PRIVATE_WEBSOCKET_URL")

    # Initialize public WebSocket connection
    public_ws = PublicStreamHandler(url=public_ws_url)
    private_ws = PrivateStreamHandler(url=private_ws_url)

    return public_ws, private_ws

async def main():
    # Configuration for market monitoring
    config = {
        "volatility_threshold": 0.05,
        "spread_threshold": 0.02,
        "cooldown_minutes": 5
    }

    # Example data for monitoring
    prices = [50000, 52500]
    bid_price = 49900
    ask_price = 51000

    try:
        # Initialize WebSocket connections
        public_ws, private_ws = initialize_connections()

        # Connect to both WebSockets
        await public_ws.connect()
        await private_ws.connect()

        # Authenticate private WebSocket
        await private_ws.authenticate()

        # Subscribe to topics (example)
        await public_ws.subscribe("TRADE", "BTC_USDT")
        await private_ws.subscribe("BALANCE")

        # Monitor market conditions in a loop
        while True:
            if monitor_market_conditions(prices, bid_price, ask_price, config):
                print(f"Pausing trading for {config['cooldown_minutes']} minutes...")
                await asyncio.sleep(config["cooldown_minutes"] * 60)

    except KeyboardInterrupt:
        print("\nBot interrupted manually. Exiting gracefully...")

    except Exception as e:
        log_error('WebSocket', 'Error', f"An error occurred in the main function: {e}")
        raise

    finally:
        # Ensure WebSocket connections are closed
        try:
            await public_ws.disconnect()
            await private_ws.disconnect()
        except Exception as cleanup_error:
            log_error("WebSocket", "CleanupError", f"Error during cleanup: {cleanup_error}")
        print("Connections closed. Goodbye.")
        # Ensure WebSocket connections are closed
        try:
            await public_ws.disconnect()
            await private_ws.disconnect()
        except Exception as cleanup_error:
            log_error("WebSocket", "CleanupError", f"Error during cleanup: {cleanup_error}")
        print("Connections closed. Goodbye.")

if __name__ == "__main__":
    try:
        asyncio.get_event_loop().run_until_complete(main())
    except KeyboardInterrupt:
        print("\nBot manually stopped. Goodbye!")