import logging

import time


def get_api_key_with_failover(task_name, api_keys):
    """Retrieves an API key for the given task, with failover logic."""
    primary_key = api_keys.get(task_name)
    backup_keys = [key for key in api_keys.values() if key != primary_key]
    
    if primary_key:
        return primary_key
    
    for backup_key in backup_keys:
        if backup_key:  # Ensure the backup key is valid
            logging.warning(f"Primary API key for task '{task_name}' unavailable. Using backup key.")
            return backup_key
    
    raise ValueError(f"No valid API keys found for task: {task_name}")
    
def exponential_backoff(attempt, base=2, cap=60):
    """Implements exponential backoff for retries."""
    return min(base ** attempt, cap)
